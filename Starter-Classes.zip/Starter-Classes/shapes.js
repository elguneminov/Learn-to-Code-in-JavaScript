import {Surface} from './surface.js';

export class Shape {
    static displayType = "Shape";
    constructor(name) {
        console.log("Building shape");
        this.name = name;
    }

    area() {
        return NaN;
    }

    perimeter() {
        return NaN;
    }
}

export class Rectangle extends Shape {
    static displayType = "Rectangle";
    width;
    height;

    constructor(name, width, height) {
        super(name);
        console.log("Building rectangle");
        this.width = width;
        this.height = height;
    }

    area() {
        return this.height * this.width;
    }

    perimeter() {
        return this.height * 2 + this.width * 2;
    }

    draw() {
        let shape = Surface.buildSurface(this.width, this.height, true);
        return shape;
    }
}

export class Square extends Rectangle {
    static displayType = "Square";
    constructor(name, width) {
        super(name, width, width);
        console.log("Building square");
    }
}