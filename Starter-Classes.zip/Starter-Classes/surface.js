export class Surface {
    drawingArea = [];
    width;
    height;

    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.drawingArea = Surface.buildSurface(width, height, false);
    }

    draw(x, y, shape) {
        let drawing = shape.draw();
        for (let i=0; i<drawing.length; i++) {
            for (let j=0; j<drawing[i].length; j++) {
                this.drawingArea[x+i][y+j] ^= drawing[i][j];
            }
        }
    }

    static buildSurface(width, height, fill) {
        let drawingArea = [];
        for (let i=0; i<height; i++) {
            drawingArea.push([]);
            for (let j=0; j<width; j++) {
                drawingArea[i].push(fill);
            }
        }
        return drawingArea;
    }

    stringify() {
        let str = "";
        for (let i=0; i<this.drawingArea.length; i++) {
            for (let j=0; j<this.drawingArea[i].length; j++) {
                str += this.drawingArea[i][j] ? "*" : " ";
            }
            str += '\n';
        }
        return str;
    }

}