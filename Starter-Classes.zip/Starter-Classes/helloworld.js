'use strict';

import {Shape, Rectangle, Square} from './shapes.js';
import {Surface} from './surface.js';

export function hello() {
    console.clear();

    let surface = new Surface(100,100);
    let rect = new Rectangle("MyRectangle", 10, 20);
    let sq = new Square("MySquare", 30);
    let sq2 = new Square("MySquare", 10);
    surface.draw(10,10,rect);
    surface.draw(50,30,rect);
    surface.draw(15,15, sq);
    surface.draw(25,25, sq2);

    let str = surface.stringify();
    console.log(str);
    let ta = document.getElementById("shapeArea");
    ta.value = str;

    console.log(Rectangle.displayType, rect, "Area: ", rect.area(), "Perimeter: ", rect.perimeter());
    console.log(Square.displayType, sq, "Area: ", sq.area(), "Perimeter: ", sq.perimeter());
}

