'use strict';
function hello() {
    console.clear();
    console.log('hello world');
}